package ifsp.edu.br.backend.repository;

import org.springframework.data.repository.CrudRepository;

import ifsp.edu.br.backend.model.Calendario;

public interface CalendarioRepository extends CrudRepository<Calendario, Long>{
}