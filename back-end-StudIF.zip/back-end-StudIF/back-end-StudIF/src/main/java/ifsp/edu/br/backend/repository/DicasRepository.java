package ifsp.edu.br.backend.repository;

import org.springframework.data.repository.CrudRepository;

import ifsp.edu.br.backend.model.Dicas;

public interface DicasRepository extends CrudRepository<Dicas, Long>{
}